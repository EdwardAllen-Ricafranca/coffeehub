<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Checkout | Brew Haven</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #fef9f5;
    }
    nav {
      background-color: #4E342E;
    }
    .navbar-brand {
      font-weight: bold;
      font-size: 2rem;
      color: #fff !important;
    }
    .navbar-brand img {
      width: 60px;
      height: 60px;
      object-fit: contain;
      border-radius: 50%;
    }
    .nav-link {
      color: #fff !important;
      font-size: 1.05rem;
    }
    .nav-link:hover {
      color: #D6A77A !important;
    }

    .form-section {
      background-color: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      margin-bottom: 40px;
    }

    .checkout-title {
      font-size: 1.5rem;
      font-weight: 600;
      color: #4B2E2A;
      margin-bottom: 20px;
    }

    .btn-placeorder {
      background-color: #D6A77A;
      color: #fff;
      padding: 12px 30px;
      font-size: 1.1rem;
      border: none;
    }

    .btn-placeorder:hover {
      background-color: #c28e67;
    }

    footer {
      background-color: #4E342E;
      color: #fff;
      padding: 30px 0;
      text-align: center;
    }

    footer a {
      color: #D6A77A;
      text-decoration: none;
      margin: 0 8px;
    }

    footer a:hover {
      text-decoration: underline;
    }

    .order-summary img {
      width: 60px;
      height: 60px;
      object-fit: contain;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark py-3">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2" href="index.php">
      <img src="images/logo.png" alt="Brew Haven Logo">
      <span>Coffee Hub</span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto gap-3">
        <li class="nav-item"><a class="nav-link" href="whatweoffer.php">What We Offer</a></li>
        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
        <li class="nav-item"><a class="nav-link" href="account.php">Account</a></li>
        <li class="nav-item"><a class="nav-link" href="aboutus.php">About Us</a></li>
        <li class="nav-item">
          <a class="nav-link" href="cart.php">
            <i class="fas fa-shopping-cart me-1"></i> Cart
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Checkout Form -->
<div class="container my-5">
  <div class="row g-5">
    <!-- Customer Info -->
    <div class="col-md-7">
      <div class="form-section">
        <h2 class="checkout-title">Customer Information</h2>
        <form id="checkoutForm">
          <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Phone</label>
            <input type="tel" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Shipping Address</label>
            <textarea class="form-control" rows="3" required></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Payment Method</label>
            <select class="form-select" required>
              <option selected disabled>Select payment method</option>
              <option value="credit">Credit Card</option>
              <option value="paypal">PayPal</option>
              <option value="cod">Cash on Delivery</option>
            </select>
          </div>
          <button type="submit" class="btn btn-placeorder">Place Order</button>
        </form>
      </div>
    </div>

    <!-- Order Summary -->
    <div class="col-md-5">
      <div class="form-section order-summary">
        <h2 class="checkout-title">Order Summary</h2>
        <div id="orderItems"></div>
        <hr />
        <p class="text-end fw-bold">Total: ₱<span id="totalPrice">0</span></p>
      </div>
    </div>
  </div>
</div>

<!-- Footer -->
<footer>
  <p>&copy; 2025 Coffee Hub | Clint Aldrich Reyes | Edward Allen Ricafranca</p>
  <a href="#">Privacy Policy</a> | <a href="#">Terms & Conditions</a> | <a href="#">Contact Us</a>
</footer>

<script>
  const orderItems = document.getElementById("orderItems");
  const totalPriceEl = document.getElementById("totalPrice");

  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  let total = 0;

  cart.forEach(item => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const el = document.createElement("div");
    el.className = "d-flex align-items-center justify-content-between mb-3";
    el.innerHTML = `
      <div class="d-flex align-items-center gap-3">
        <img src="${item.image}" alt="${item.name}">
        <div>
          <div class="fw-semibold">${item.name}</div>
          <small>Qty: ${item.quantity}</small>
        </div>
      </div>
      <div>₱${itemTotal}</div>
    `;
    orderItems.appendChild(el);
  });

  totalPriceEl.textContent = total;

  // Place Order Handler
  document.getElementById("checkoutForm").addEventListener("submit", function (e) {
    e.preventDefault();
    alert("✅ Thank you! Your order has been placed.");
    localStorage.removeItem("cart");
    window.location.href = "index.php";
  });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
